<?php
include_once('resources/init.php');
//$posts = (isset($_GET['id'])) ? get_posts($_GET['id']) : get_posts();
$posts = get_posts((isset($_GET['id']))? $_GET['id'] : null); 
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Blog</title>
        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="//cdn.muicss.com/mui-0.9.15/css/mui.min.css" rel="stylesheet" type="text/css" />
		<script src="//cdn.muicss.com/mui-0.9.15/js/mui.min.js"></script>
        <!--<style>
            ul{list-style: none;}
            li{display: inline; margin-right: 20px;}
        </style>-->
        <style>
        header {
  position: sticky;
  top: 0;
  right: 0;
  left: 0;
  z-index: 2;
  color: #fff;
}

td ul li a {
	color: #fff;
	height: 100%;
}
        </style>
    </head>
    <body>
    <!--  <nav>
        <ul>
            <li><a href='index.php' >Index</a></li>
            <li><a href='add_post.php' >Add a Post</a></li>
            <li><a href='add_category.php' >Add Category</a></li>
            <li><a href='category_list.php' >Category List</a></li>
            <li><a href='' ></a></li>
        </ul>
     </nav> -->
     <header class="mui-appbar mui--z1">
  		<!-- Appbar HTML goes here -->
  		<div class="mui-container">
  <table width="100%">
    <tr class="mui--appbar-height">
      <td class="mui--text-title"> Simple Blog</td>
      <td align="right">
        <ul class="mui-list--inline">
            <li><a href='index.php'>Index</a></li>
            <li><a href='add_post.php'>Add a Post</a></li>
            <li><a href='add_category.php'>Add Category</a></li>
            <li><a href='category_list.php'>Category List</a></li>
            <li><a href='#'></a></li>
        </ul>
      </td>
    </tr>
  </table>
</div>
	</header>
	<div class="mui-container-fluid" style = "margin-top: 1vw;">
     
     
     <?php
     foreach($posts as $post){
      ?>
     <h2><a href='index.php?id=<?php echo $post['post_id']; ?>' ><?php echo $post['title']; ?></a></h2>
     <p>
        Posted on <?php echo date('d-m-y h:i:s',strtotime($post['date_posted'])); ?>
        In <a href='category.php?id=<?php echo $post['category_id']; ?>' ><?php echo $post['name']; ?></a>
     </p>
     <div><?php echo nl2br($post['contents']); ?></div>
     <menu>
        
            <a href='delete_post.php?id=<?php echo $post['post_id']; ?>' class="mui-btn mui-btn--danger">&#x2715;</a>
            <a href='edit_post.php?id=<?php echo $post['post_id']; ?>' class="mui-btn mui-btn--primary">&#x270E;</a>
        
     </menu>
     </div>
     <?php   
     }
     ?>
    </body>
</html>